def test_call(params=None):
    print("params = ", params)
    return 100
